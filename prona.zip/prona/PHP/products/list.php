<?php
// /PHP/products/list.php
require_once __DIR__ . '/../config.php';
$pdo = getPDO();

$categoria = $_GET['categoria'] ?? null;

if ($categoria) {
    $stmt = $pdo->prepare("SELECT p.*, c.nombre_categoria FROM producto p JOIN categoria c ON p.id_categoria=c.id_categoria WHERE p.id_categoria = ?");
    $stmt->execute([$categoria]);
} else {
    $stmt = $pdo->query("SELECT p.*, c.nombre_categoria FROM producto p JOIN categoria c ON p.id_categoria=c.id_categoria ORDER BY p.nombre_producto");
}
$rows = $stmt->fetchAll();
jsonResponse(['data'=>$rows]);
