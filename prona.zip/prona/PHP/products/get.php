<?php
require_once __DIR__ . '/../config.php';
$pdo = getPDO();
if (empty($_GET['id'])) jsonResponse(['error'=>'id required'],400);
$stmt = $pdo->prepare("SELECT * FROM producto WHERE id_producto = ?");
$stmt->execute([$_GET['id']]);
$row = $stmt->fetch();
if (!$row) jsonResponse(['error'=>'Not found'],404);
jsonResponse($row);
