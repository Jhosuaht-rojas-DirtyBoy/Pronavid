<?php
require_once __DIR__ . '/../config.php';
$pdo = getPDO();
$stmt = $pdo->query("SELECT v.*, u.primer_nombre, u.primer_apellido FROM venta v JOIN usuario u ON v.id_usuario=u.id_usuario ORDER BY v.fecha_venta DESC");
jsonResponse(['data'=>$stmt->fetchAll()]);
