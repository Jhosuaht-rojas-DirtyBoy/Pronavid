<?php
require_once __DIR__ . '/../config.php';
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$required = ['id_usuario','subtotal','items'];
foreach ($required as $r) if (!isset($input[$r])) jsonResponse(['error'=>"Missing $r"],422);

$pdo = getPDO();
try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO venta (subtotal, descuento, impuestos, id_pedido, id_usuario) VALUES (?,?,?,?,?)");
    $stmt->execute([$input['subtotal'],$input['descuento'] ?? 0,$input['impuestos'] ?? 0,$input['id_pedido'] ?? null,$input['id_usuario']]);
    $id_venta = $pdo->lastInsertId();

    $stmtDet = $pdo->prepare("INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario) VALUES (?,?,?,?)");
    foreach ($input['items'] as $it) {
        $stmtDet->execute([$id_venta, $it['id_producto'], $it['cantidad'], $it['precio_unitario']]);
    }
    $pdo->commit();
    jsonResponse(['ok'=>true,'id_venta'=>$id_venta],201);
} catch (PDOException $e) {
    $pdo->rollBack();
    jsonResponse(['error'=>$e->getMessage()],500);
}
