<?php
require_once __DIR__ . '/../config.php';
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
if (empty($input['id_cliente']) || empty($input['id_usuario'])) jsonResponse(['error'=>'Missing data'],422);

$pdo = getPDO();
try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO pedido (id_cliente,id_usuario) VALUES (?,?)");
    $stmt->execute([$input['id_cliente'],$input['id_usuario']]);
    $id_pedido = $pdo->lastInsertId();

    if (!empty($input['items'])) {
        $stmtDet = $pdo->prepare("INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)");
        // Nota: detalle_venta requiere una venta; en un flujo real harías primero la venta y relacionarías o usarías otra tabla detalle_pedido.
        // Por simplicidad guardamos los items en detalle_cotizacion o la tabla de pedidos detallados si la creas.
    }

    $pdo->commit();
    jsonResponse(['ok'=>true,'id_pedido'=>$id_pedido],201);
} catch (PDOException $e) {
    $pdo->rollBack();
    jsonResponse(['error'=>$e->getMessage()],500);
}
