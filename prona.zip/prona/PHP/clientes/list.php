<?php
require_once __DIR__ . '/../config.php';
$pdo = getPDO();
$stmt = $pdo->query("SELECT * FROM cliente ORDER BY nombre_cliente");
jsonResponse(['data'=>$stmt->fetchAll()]);
