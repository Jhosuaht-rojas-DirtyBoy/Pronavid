<?php
require_once __DIR__ . '/../config.php';
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$required = ['nombre_cliente','identificacion'];
foreach ($required as $r) if (empty($input[$r])) jsonResponse(['error'=>"Missing $r"],422);

$pdo = getPDO();
try {
    $stmt = $pdo->prepare("INSERT INTO cliente (nombre_cliente, identificacion, correo_cliente, telefono_cliente, direccion_cliente) VALUES (?,?,?,?,?)");
    $stmt->execute([
        $input['nombre_cliente'],
        $input['identificacion'],
        $input['correo_cliente'] ?? null,
        $input['telefono_cliente'] ?? null,
        $input['direccion_cliente'] ?? null
    ]);
    jsonResponse(['ok'=>true, 'id_cliente'=>$pdo->lastInsertId()],201);
} catch (PDOException $e) {
    jsonResponse(['error'=>$e->getMessage()],500);
}
