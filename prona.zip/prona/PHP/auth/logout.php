<?php
// /PHP/auth/logout.php
require_once __DIR__ . '/../config.php';
session_destroy();
jsonResponse(['ok'=>true]);
