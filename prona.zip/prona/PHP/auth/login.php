<?php
// /PHP/auth/login.php
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error'=>'Use POST'],405);
$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (empty($data['correo']) || empty($data['contrasena'])) jsonResponse(['error'=>'Missing credentials'],422);

$pdo = getPDO();
$stmt = $pdo->prepare("SELECT id_usuario, primer_nombre, primer_apellido, correo, contrasena, id_rol FROM usuario WHERE correo = ? LIMIT 1");
$stmt->execute([$data['correo']]);
$user = $stmt->fetch();

if (!$user) jsonResponse(['error'=>'Usuario no encontrado'],404);

if (!password_verify($data['contrasena'], $user['contrasena'])) {
    jsonResponse(['error'=>'Credenciales inválidas'],401);
}

// remover contrasena
unset($user['contrasena']);

// guardar en sesión
$_SESSION['user'] = [
    'id' => (int)$user['id_usuario'],
    'nombre' => $user['primer_nombre'].' '.$user['primer_apellido'],
    'id_rol' => (int)$user['id_rol'],
    'correo' => $user['correo']
];

jsonResponse(['ok'=>true, 'user'=>$_SESSION['user']]);
