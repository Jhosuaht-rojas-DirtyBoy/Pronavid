<?php
// /PHP/auth/register.php
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error'=>'Use POST'], 405);
}

$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

$required = ['primer_nombre','primer_apellido','tipo_documento','numero_documento','correo','contrasena'];
foreach ($required as $r) {
    if (empty($data[$r])) jsonResponse(['error'=>"Missing $r"], 422);
}

$pdo = getPDO();

// default role (Asesor)
$id_rol = $data['id_rol'] ?? 2; // 1=admin 2=asesor (depende de tu seed)

try {
    $hash = password_hash($data['contrasena'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO usuario (primer_nombre, primer_apellido, tipo_documento, numero_documento, correo, contrasena, id_rol) VALUES (?,?,?,?,?,?,?)");
    $stmt->execute([
        $data['primer_nombre'],
        $data['primer_apellido'],
        $data['tipo_documento'],
        $data['numero_documento'],
        $data['correo'],
        $hash,
        $id_rol
    ]);

    jsonResponse(['ok'=>true, 'id_usuario' => $pdo->lastInsertId()], 201);

} catch (PDOException $e) {
    if ($e->getCode() === '23000') { // duplicate
        jsonResponse(['error'=>'Registro ya existe (correo o documento duplicado)'], 409);
    }
    jsonResponse(['error'=>$e->getMessage()], 500);
}
