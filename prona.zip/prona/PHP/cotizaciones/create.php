<?php
require_once __DIR__ . '/../config.php';
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
if (empty($input['id_usuario']) || empty($input['id_cliente']) || empty($input['items'])) jsonResponse(['error'=>'Missing data'],422);

$pdo = getPDO();
try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO cotizacion (id_usuario,id_cliente) VALUES (?,?)");
    $stmt->execute([$input['id_usuario'],$input['id_cliente']]);
    $id_cot = $pdo->lastInsertId();

    $stmtDet = $pdo->prepare("INSERT INTO detalle_cotizacion (id_cotizacion,id_producto,cantidad,precio_unitario) VALUES (?,?,?,?)");
    foreach ($input['items'] as $it) {
        $stmtDet->execute([$id_cot, $it['id_producto'], $it['cantidad'], $it['precio_unitario']]);
    }
    $pdo->commit();
    jsonResponse(['ok'=>true,'id_cotizacion'=>$id_cot],201);
} catch (PDOException $e) {
    $pdo->rollBack();
    jsonResponse(['error'=>$e->getMessage()],500);
}
