<?php
// /PHP/includes/footer.php
?>
<footer class="site-footer">
  <p>Industrias Alimenticias Pronavid © <?php echo date('Y'); ?></p>
</footer>
