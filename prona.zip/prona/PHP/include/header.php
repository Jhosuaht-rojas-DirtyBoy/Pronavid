<?php
// /PHP/includes/header.php
?>
<header class="site-header">
  <div class="logo">
    <a href="/HTML/index.html"><img src="/img/Logopronavid.png" alt="Logo"></a>
  </div>
  <nav>
    <a href="/HTML/index.html">Inicio</a>
    <a href="/HTML/catalogo.html">Catálogo</a>
    <a href="/HTML/dashboard.html">Dashboard</a>
  </nav>
</header>
