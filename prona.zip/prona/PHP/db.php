<?php
// /PHP/db.php
declare(strict_types=1);

function getPDO(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;

    $host = '127.0.0.1';
    $db   = 'pronavid'; // Cambia si tu BD tiene otro nombre
    $user = 'root';
    $pass = '';         // en XAMPP por defecto empty
    $port = 3306;
    $dsn  = "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4";

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
        return $pdo;
    } catch (PDOException $e) {
        header('Content-Type: application/json; charset=utf-8', true, 500);
        echo json_encode(['error' => 'DB connection failed: '.$e->getMessage()]);
        exit;
    }
}
