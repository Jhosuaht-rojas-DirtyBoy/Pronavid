<?php
// /PHP/config.php
session_start();
require_once __DIR__ . '/db.php';

function jsonResponse($data, $status = 200) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($status);
    echo json_encode($data);
    exit;
}

function requireAuth() {
    if (!isset($_SESSION['user'])) {
        jsonResponse(['error'=>'Unauthorized'], 401);
    }
}
